JMS FiberNet Portal - Demo Version

Files:
index.html     Public website
customer.html  Customer login + dashboard + recharge demo
admin.html     Admin login + dashboard demo

DEMO LOGIN
Customer: customer / 1234
Admin: admin / admin123

IMPORTANT:
This is a front-end demo. It does NOT securely authenticate users, store real customer data, or process real payments.
For production, connect a backend/database and payment gateway (e.g. Razorpay/UPI), and integrate your ISP/PPPoE billing system.
